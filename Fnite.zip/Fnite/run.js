// require the package
const Fortnite = require("fortnite-api");

let fortniteAPI = new Fortnite(
    [
        "the3gamingstars@gmail.com",
        "fortnite1",
        "MzRhMDJjZjhmNDQxNGUyOWIxNTkyMTg3NmRhMzZmOWE6ZGFhZmJjY2M3Mzc3NDUwMzlkZmZlNTNkOTRmYzc2Y2Y=",
        "ZWM2ODRiOGM2ODdmNDc5ZmFkZWEzY2IyYWQ4M2Y1YzY6ZTFmMzFjMjExZjI4NDEzMTg2MjYyZDM3YTEzZmM4NGQ="
    ],
    {
        debug: true
    }
);

fortniteAPI.login().then(() => {
    fortniteAPI
        .getStatsBR("JunkAthelete8291", "xb1")
        .then(stats => {
            console.log(stats);
        })
        .catch(err => {
            console.log(err);
        });
});